        Housemarque Audio System, release 0.40a
        ---------------------------------------

Copyright 1996,1997,1998,1999 Housemarque Inc.

This archive contains the Housemarque Audio System, release 0.40a, inside the
file "hmqaudio.zip".

The system supports hardware, compilers, and operating systems no longer
available to us, and therefore we have not been able to re-build the
distribution and verify it still works. To avoid problems, "hmqaudio.zip"
contains the original release of "MIDAS Digital Audio System", version 0.40a,
and thus most of the documentation and source code inside the file still uses
that name. The name is obsolete, however, and all material referring to the
system must use the current name, "Housemarque Audio System".

Note that this is obsolete and only supports the MS-DOS operating system.


If you have any questions, contact us:

Technical issues: Petteri Kangaslampi, e-mail pekangas@sci.fi
Licensing issues: Housemarque Inc., e-mail hmqaudio@housemarque.fi

More information is available at http://www.housemarque.fi/ and
http://www.s2.org/hmqaudio/.
